package pt.ufp.info.esof.projeto.dtos;

public interface CreateDTO<M> {
    M converter();
}

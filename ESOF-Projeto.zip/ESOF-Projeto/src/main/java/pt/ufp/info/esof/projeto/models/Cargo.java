package pt.ufp.info.esof.projeto.models;

import lombok.Getter;

@Getter
public enum Cargo {
    DEV_JR, DEV_SR, AN_JR, AN_SR;
}
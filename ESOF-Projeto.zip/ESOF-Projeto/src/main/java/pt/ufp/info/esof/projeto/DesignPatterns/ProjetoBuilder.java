package pt.ufp.info.esof.projeto.DesignPatterns;

public class ProjetoBuilder {
    private Projeto projeto;

    public void Projeto(String nome){
        this.projeto=new Projeto();

    }
}

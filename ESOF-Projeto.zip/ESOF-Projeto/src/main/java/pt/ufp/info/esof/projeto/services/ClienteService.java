package pt.ufp.info.esof.projeto.services;

import pt.ufp.info.esof.projeto.models.Cliente;
import pt.ufp.info.esof.projeto.models.TarefaEfetiva;

import java.util.List;

public interface ClienteService {
    List<Cliente> findAll();


}
